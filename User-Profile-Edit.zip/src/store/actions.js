export const STORE_USERS = 'STORE_USERS';
export const MODIFY_USER = 'MODIFY_USER';
