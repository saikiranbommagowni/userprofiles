import './App.css';

import { connect } from 'react-redux';
import * as actionTypes from 'store/actions';
import { useEffect } from 'react';

import {
  BrowserRouter as Router,
  Route,
  Redirect,
  Switch
} from 'react-router-dom';

import Users from 'containers/Users/Users';
import UserModify from 'containers/Users/UserModify';

function App(props) {
  useEffect(()=>{
    // const url = 'https://my-json-server.typicode.com/saikiranbommagowni/jsonserver';
    const url="https://jsonplaceholder.typicode.com/users";
    fetch(url).then(res=>res.json()).then(data=>props.onStoreUsers(data));
},[]);

  return (
    <Router>
      <main>
        <Switch>
          <Route path="/" exact>
            <Users usersData={props.usersData}/>
          </Route>
          <Route path="/:userId/modify">
            <UserModify usersData={props.usersData}/>
          </Route>
          <Redirect to="/" />
        </Switch>
      </main>
    </Router>
  );
}
const mapStateToProps = state => {
  return {
      usersData: state.usersReducer.users
  }
}

const mapDispatchToProps = dispatch => {
  return {
      onStoreUsers:(data)=>dispatch({type:actionTypes.STORE_USERS, usersData:data})
  }

}
export default connect(mapStateToProps, mapDispatchToProps)(App);
